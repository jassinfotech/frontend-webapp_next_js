'use client'
import React, { useState, useEffect, useRef } from 'react';
import 'bootstrap/dist/css/bootstrap.css'
import Sidebarmain from '../component/Sidebarmain';
import '../scss/style.scss';
import Modal from 'react-modal';
import { FaSearch, FaSlidersH, FaEllipsisV, FaWallet } from "react-icons/fa";
import { AiOutlineClose } from "react-icons/ai";
import { MdOutlineArrowBack } from "react-icons/md";

import Link from 'next/link';
import './addbeneficiary.css';
function page() {



  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [value, setValue] = useState(false);
  const toggleFilter = () => {
    setIsFilterOpen(!isFilterOpen);
  };
  const handleClick = () => {
    setValue(!value);
  };
  const [modalIsOpenbals, setIsOpenbals] = useState(false);
  const [modalIsOpen, setIsOpen] = useState(false);
  const [modalIsUplordbal, setImodalIsUplordbal] = useState(false);


  function openModal() {
    setIsOpen(true);
  }
  function closeModal() {
    setIsOpen(false);
  }
  const customStyles = {
    content: {
      top: '50%',
      left: '50%',
      right: 'auto',
      bottom: 'auto',
      marginRight: '-50%',
      transform: 'translate(-50%, -50%)',
      width: '397px',
      paddingTop: '10px',
      border: '1px solid rgb(196 196 196 / 30%)',
      boxShadow: '2px 5px 60px -32px #28A5C1',

    },
  };




  return (
    <>
      <Sidebarmain />
      <section id="main" className='main'>
        <div className='container-fluid p-5'>
          <div className="row">
            <div className='col'>
              <a className='back_btn_emp' href=''><MdOutlineArrowBack className='mx-1' size={25} />Back</a>
            </div>

          </div>

        <div className="p-4">
        <div className='row d-flex pt-3'>
            <div className='col-lg-4 pb-3 pt-4'>
              <div className='employee_text'>Add beneficiary</div>
            </div>

          </div>
          <div className="row pt-4">
            <div className="col-lg-6">
              <div className="num_ber">
                <label for="exampleFormControlInput1" className="form-label">Account number </label>
                <input type="text" className="form-control ban_k" id="exampleFormControlInput1" placeholder="Example@79454157022" />
              </div>
            </div>
            <div className="col-lg-6">
              <div className="num_ber">
                <label for="exampleFormControlInput1" className="form-label">Confirm Account number </label>
                <input type="text" className="form-control ban_k" id="exampleFormControlInput1" placeholder="Enter confirm Account number" />
              </div>
            </div>
          </div>
          <div className="row pt-4">
            <div className="col-lg-6">
              <div className="num_ber">
                <label for="exampleFormControlInput1" className="form-label">Select bank </label>
                <select className="form-select ban_k" aria-label="Default select example">
                  <option selected>Select bank</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="num_ber">
                <label for="exampleFormControlInput1" className="form-label">Bank IFSC Code </label>
                <input type="text" className="form-control ban_k" id="exampleFormControlInput1" placeholder="Enter IFSC Code" />
              </div>
            </div>
          </div>
          <div className="row pt-4">
            <div className="col-lg-6">
              <div className="num_ber">
                <label for="exampleFormControlInput1" className="form-label">Beneficiary name </label>
                <input type="text" className="form-control ban_k" id="exampleFormControlInput1" placeholder="Enter beneficiary name" />
              </div>
            </div>
            <div className="col-lg-6">
              <div className="num_ber">
                <label for="exampleFormControlInput1" className="form-label">Mobile number</label>
                <input type="text" className="form-control ban_k" id="exampleFormControlInput1" placeholder="Enter mobile number" />
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-3">
              <button className='but_sub'>Submit</button>
            </div>
          </div>

        </div>
        </div>

      </section>

      <Modal isOpen={modalIsOpen} style={customStyles} contentLabel="Example Modal" overlayClassName="Overlay">
        <div className='row'>
          <div className='col-md-10 col-lg-10 text-start pt-0 mt-0'>
            <div>Information</div>
          </div>
          <div className='col-md-2 col-lg-2 text-end pt-0 mt-0'>
            <a onClick={closeModal}><AiOutlineClose size={23} /></a>
          </div>
          <div className='col-md-12 col-lg-12 pt-2 pb-5'>
            <h5 className='text-drck text-center pt-3 px-5'>Are you sure  you Want to Save Changes?</h5>
          </div>
          <div className='col-md-12 col-lg-12 pt-3 pb-3 text-center'>
            <button className='btn btn-cancel me-2'>Cancel</button>
            <button className='btn btn-ok ms-2 '>Ok</button>

          </div>
        </div>

      </Modal>

      <Modal isOpen={modalIsOpenbals} style={customStyles} contentLabel="Example Modal" overlayClassName="Overlay">
        <div className='row'>
          <div className='col-md-10 col-lg-10 text-start pt-0 mt-0'>
            <div className='poipuptext'>Add Balance</div>
          </div>
          <div className='col-md-2 col-lg-2 text-end pt-0 mt-0'>
            <a onClick={() => setIsOpenbals(false)}><AiOutlineClose size={23} /></a>
          </div>
          <div className='col-md-12 col-lg-12 pt-2 pb-5'>
            <h5 className='text-drck text-center pb-4 pt-3 px-5'>Add Balance</h5>
            <input type="number" className="form-control" placeholder='Enter Amount' />
          </div>
          <div className='col-md-12 col-lg-12 pt-3 pb-3 text-end'>
            <button className='btn btn-cancel me-2' onClick={() => setIsOpenbals(false)}>Cancel</button>
            <button className='btn btn-ok ms-2 ' onClick={() => setImodalIsUplordbal(true)}>Ok</button>

          </div>
        </div>
      </Modal>
      <Modal isOpen={modalIsUplordbal} style={customStyles} contentLabel="Example Modal" overlayClassName="Overlay">
        <div className='row'>
          <div className='col-md-10 col-lg-10 text-start pt-0 mt-0'>
            <div className='poipuptext'>Information</div>
          </div>
          <div className='col-md-2 col-lg-2 text-end pt-0 mt-0'>
            <a onClick={() => setImodalIsUplordbal(false)}><AiOutlineClose size={23} /></a>
          </div>
          <div className='col-md-12 col-lg-12 pt-2 pb-5 px-3'>
            <h5 className='top_popup_text pb-4 pt-3 '>Add Or Update Employee Bulk Balance</h5>
            <div className='uploadtext '>Download exel File </div>
            <div className="card shadow-none  mx-auto">
              <div className="card-body text-center p-5">
                <a id="uploadButton" className='fileuplord'> <img src='../images/Downarrow.png' alt='image' /></a><br />
              </div>
            </div>
            <div className='uploadtext pt-3 '>Upload File </div>
            <div className="card shadow-none mx-auto">
              <div className="card-body text-center p-5">
                <a id="uploadButton" className='fileuplord'> <img src='../images/Uploadimage.png' alt='image' /></a><br />
              </div>
            </div>
            <div className='file_text ps-3 pt-3 pb-4 '>If you want to know about more how to add balance  <a className='text_clr text-decoration-none' href='#'>www.youtube.com</a></div>
          </div>
          <div className='col-md-12 col-lg-12 pt-3 pb-3 text-end'>
            <button className='btn btn-cancel me-2' onClick={() => setImodalIsUplordbal(false)}>Cancel</button>
            <button className='btn btn-ok ms-2 ' onClick={() => setImodalIsUplordbal(false)}>Ok</button>

          </div>
        </div>
      </Modal>


    </>
  )
}

export default page